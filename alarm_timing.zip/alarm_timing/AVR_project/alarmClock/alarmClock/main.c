/*
 * alarmClock.c
 *
 * Created: 5/20/2021 5:01:29 PM
 * Author : user
 */ 

#include <avr/io.h>
#include "stdutils.h"
#include <util/delay.h>

typedef struct { 
	int sec;  //allocating int memory for storing seconds
	int min;  //allocating int memory for storing minutes
	int hour;  //allocating int memory for storing hours
	int weekDay; //allocating int memory for storing weekday
	int date;  //allocating int memory for storing date
	int month;  //allocating int memory for storing month
	int year;  //allocating int memory for storing year
}rtc_t;
#define Ds3232ReadMode 0xD1u  // DS3232 ID
#define Ds3232WriteMode 0xD0u  // DS3232 ID
#define Ds3232SecondRegAddress  0x00u   // Address to access Ds3232 SEC register
#define Ds3232DateRegAddress     0x04u   // Address to access Ds3232 DATE register
#define Ds3232ControlRegAddress  0x07u   // Address to access Ds3232 Control register

void I2C_Init() //Initialize I2C Communication
{
	TWSR=0x00; //set presca1er bits to zero
	TWBR=0x46; //SCL frequency is 50K for 16Mhz
	TWCR=0x04; //enab1e TWI module
}
void I2C_Start()  //Start I2C Communication
{
	TWCR = ((1<<TWINT) | (1<<TWSTA) | (1<<TWEN));
	while (!(TWCR & (1<<TWINT)));
}
void I2C_Stop(void)  //Stop I2C Communication
{
	TWCR = ((1<< TWINT) | (1<<TWEN) | (1<<TWSTO));
	_delay_us(100) ; //wait for a short time
}
void I2C_Write(uint8_t v_i2cData_u8) //Write data to I2C data line
{
	TWDR = v_i2cData_u8 ;
	TWCR = ((1<< TWINT) | (1<<TWEN));
	while (!(TWCR & (1 <<TWINT)));
}
uint8_t I2C_Read(uint8_t v_ackOption_u8)  //Read data from I2C data line
{
	TWCR = ((1<< TWINT) | (1<<TWEN) | (v_ackOption_u8<<TWEA));
	while ( !(TWCR & (1 <<TWINT)));
	return TWDR;
}

void RTC_Initialize(void){ //Initialize RTC
	I2C_Init();
	I2C_Start();
	I2C_Write(Ds3232WriteMode);
	I2C_Write(Ds3232ControlRegAddress);
	I2C_Write(0x00);
	I2C_Stop();
}
void RTC_Set_Time(rtc_t *rtc){  //Write Date time values to the memory
	I2C_Start();
	I2C_Write(Ds3232WriteMode);
	I2C_Write(Ds3232SecondRegAddress);
	I2C_Write(rtc->sec);
	I2C_Write(rtc->min);
	I2C_Write(rtc->hour);
	I2C_Write(rtc->weekDay);
	I2C_Write(rtc->date);
	I2C_Write(rtc->month);
	I2C_Write(rtc->year);
	I2C_Stop();
}
void RTC_Get_Time(rtc_t *rtc){ //Get date time values from memory
	I2C_Start();
	I2C_Write(Ds3232WriteMode);
	I2C_Write(Ds3232SecondRegAddress);
	I2C_Stop();
	I2C_Start();
	I2C_Write(Ds3232ReadMode);
	rtc->sec=I2C_Read(1);
    rtc->min = I2C_Read(1);                  
    rtc->hour= I2C_Read(1);                
    rtc->weekDay = I2C_Read(1);          
    rtc->date= I2C_Read(1);              
    rtc->month=I2C_Read(1);            
    rtc->year =I2C_Read(0);              
	I2C_Stop();                              
}

int main() {
	DDRC = 0x00;  //Set C port for input
	PORTC |= (1<<PORTC4) & (1<<PORTC5);  //Setting internal pull ups 
	DDRD = 0xff;  //Set D port for output
	int alarmHour1= 0x10;  //Set alarm times
	int alarmMin1= 0x41;
	int alarmHour2= 0x10;
	int alarmMin2= 0x45;
    rtc_t rtc;

    RTC_Initialize();
    rtc.hour = 0x10;  //Initiate Date and Time
    rtc.min =  0x40;
    rtc.sec =  0x50;
	rtc.weekDay = 0x03;
	rtc.date = 0x09; 
    rtc.month = 0x06;
    rtc.year = 0x21; 
	
	RTC_Set_Time(&rtc);   //Set Date and time in DS3232
	while(1)
    {
        RTC_Get_Time(&rtc);	  //Get Date and time from DS3232
		if ((rtc.hour==alarmHour1 && rtc.min==alarmMin1) || (rtc.hour==alarmHour2 && rtc.min==alarmMin2)){ //Check for alarm
			PORTD |= (1<<PORTD7);  //Light up LED
			_delay_ms(200);
		}
		PORTD &= ~(1<<PORTD7);
		_delay_ms(200);
		
    }

    return (0);
}


